# 20230905_233442
echo "Do the followings:

cd huggingface;
source .env/bin/activate;
";


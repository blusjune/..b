#!/bin/bash
# 20230927_224836

(cd wd;
wget https://www.python.org/ftp/python/3.11.5/Python-3.11.5.tgz;
)


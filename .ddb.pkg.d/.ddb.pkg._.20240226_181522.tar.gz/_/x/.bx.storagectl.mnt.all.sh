#!/bin/bash
# 20240211_145528

source /_b/x/.blib.storagectl.drive_mount.sh

_storagectl__mount_all_usb_storage_drives;
_storagectl__list_all_usb_storage_drives;

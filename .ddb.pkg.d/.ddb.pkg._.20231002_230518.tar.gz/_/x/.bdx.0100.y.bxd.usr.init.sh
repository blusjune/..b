mkdir -p ~/..bxd/_/usr
(cd ~/..bxd/_/usr
	mkdir -p bin etc include lib share src tmp var
)

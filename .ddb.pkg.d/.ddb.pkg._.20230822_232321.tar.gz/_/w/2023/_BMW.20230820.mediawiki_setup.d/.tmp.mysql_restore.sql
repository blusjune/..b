show databases;
show tables from matrix;

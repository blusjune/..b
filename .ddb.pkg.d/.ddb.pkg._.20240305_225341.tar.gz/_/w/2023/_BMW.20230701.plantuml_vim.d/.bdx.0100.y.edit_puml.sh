#!/bin/bash

echo ":PlantumlOpen";
sleep 1;
echo ":PlantumlSave";
sleep 1;
vi PBSSD_workflow.puml

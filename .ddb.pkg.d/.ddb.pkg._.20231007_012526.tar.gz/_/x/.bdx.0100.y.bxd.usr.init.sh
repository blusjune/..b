mkdir -p ~/..bxd/_/usr
(cd ~/..bxd/_/usr
	mkdir -p bin etc include lib sbin share src tmp var
)

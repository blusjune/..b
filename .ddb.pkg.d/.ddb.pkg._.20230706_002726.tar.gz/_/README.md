# /home/blusjune/..b/_
# README
# Sat Jul  1 00:57:05 PDT 2023

c: configuration
d: data
m: memo (text)
s: shortcut
t: temporary
w: work
x: executables

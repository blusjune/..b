#!/bin/bash

_bxd="..bxd";

mkdir -p ${_bxd}/_;
cd $_bxd/_;
mkdir -p log obj src wip;

